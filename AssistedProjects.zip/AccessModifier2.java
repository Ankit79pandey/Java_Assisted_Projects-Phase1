package AssistedProjects;

public class AccessModifier2 {

}
