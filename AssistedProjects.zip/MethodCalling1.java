package AssistedProjects;

public class MethodCalling1 {

}
