package AccessModifier3;

public class AccessModifier3 {

}
