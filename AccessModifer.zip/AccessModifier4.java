package AccessModifier3;

public class AccessModifier4 {

}
